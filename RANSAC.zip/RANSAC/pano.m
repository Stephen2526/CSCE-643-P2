function [] = pano(otlrNum)
% main function
tic
%% initialize 20 pairs of points
% Input Images
imgA = imread('a.jpg');
imgB = imread('b.jpg');
% obtain gray images
igA=im2double(rgb2gray(imgA));
igB=im2double(rgb2gray(imgB));

% load manually picked points
pntsManA = [1992, 2082, 2086, 2090, 2098, 2155, 2254, 2261, 2161, 2280, 2175, 2336, 2446, 2456, 2345, 2351, 2463, 2472, 2484, 2366; 
           654, 636, 815, 941, 1382, 620, 598, 787, 803, 1385, 1385, 582, 558, 756, 773, 910, 896, 1102, 1389, 1388; 
           1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1];
pntsManB = [14., 116., 100., 89., 56., 195., 298., 285., 181., 248., 139., 380., 487., 475., 369., 359., 467., 458., 445., 333.; 
           620., 615., 800., 933., 1395., 610., 605., 794., 797., 1395., 1396., 601., 597., 786., 792., 926., 923., 1120., 1397., 1398.; 
           1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1.];

% live pick points

%% DLT to calculate H: A->B
% H = DLT(pntsManA, pntsManB);
% % normalize H
% scale1 = 1/H(3,3);
% H = H*scale1;

%% Normalized DLT
% [norPtsA, TA] = normalise2dpts(pntsManA);
% [norPtsB, TB] = normalise2dpts(pntsManB);
% norH = DLT(norPtsA, norPtsB);
% H = TB\norH*TA;

%% MLE
% H = MLE(pntsManA, pntsManB);

%% RANSAC
[ptsA,ptsB] = generateOtlr(otlrNum);
% [H,idx] = findHomography(ptsA,ptsB,20);

idx = [1     2     3     4     5     6     7     8     9    10    11    12    13    14    15    17    18    20];
ptsA = [ptsA;ones(1,size(ptsA,2))];
ptsB = [ptsB;ones(1,size(ptsB,2))];

% optimal estimation
thrErr = 1000;
disErr = inf;
while  disErr > thrErr
    H = MLE(ptsA(:,idx), ptsB(:,idx));
    [disErr,~] = calError(H, ptsA(1:2,idx), ptsB(1:2,idx), 'sam');
end
H
strH = strcat('H',int2str(otlrNum),'.mat');
save(strH,'H');
%toc

%% calculate error
algErr = calError(H,pntsManA(1:2,:),pntsManB(1:2,:),'alg')
sytErr = calError(H,pntsManA(1:2,:),pntsManB(1:2,:),'syt')
samErr = calError(H,pntsManA(1:2,:),pntsManB(1:2,:),'sam')

%% warp image
% Transpose homography matrix
H_transposed = transpose(H);

% Create form for projective 2D transformation
tform = projective2d(H_transposed);

% Warp input image
[recImgA, RrecImgA] = imwarp(imgA, tform);
% show image
%figure(1), imshow(recImgA,RrecImgA);
imgName = strcat('RANSAC', int2str(otlrNum), '_recImgA.jpg');
imwrite(recImgA, imgName);

% %% build a panorama
% RimgB = imref2d(size(imgB));
% 
% [panoImg, Rpano] = stitchPano(recImgA, RrecImgA, imgB, RimgB);
% %[panoImg, Rpano] = imfuse(recImgA, RrecImgA, imgB, RimgB, 'blend','Scaling','none');
% 
% % show image
% figure(2), imshow(panoImg,Rpano);
% %stitch(imgA, imgB, H);
% imwrite(recImgA, 'RANSAN500_recImgA.jpg');
% imwrite(panoImg, 'RANSAC500_panoImg.jpg');
end
