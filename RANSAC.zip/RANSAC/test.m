% for group testing
clc;clear;close all;
disp('700');
pano(700);
disp('2000');
pano(2000);
