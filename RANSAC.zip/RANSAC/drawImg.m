function [ ] = drawImg( H )
%UNTITLED2 Summary of this function goes here
%   draw rectified image and panorama
% Input Images
imgA = imread('a.jpg');
imgB = imread('b.jpg');

%% warp image
% Transpose homography matrix
H_transposed = transpose(H);

% Create form for projective 2D transformation
tform = projective2d(H_transposed);

% Warp input image
[recImgA, RrecImgA] = imwarp(imgA, tform);
% show image
%figure(1), imshow(recImgA,RrecImgA);
imgName = strcat('RANSAC', int2str(20), '_recImgA.jpg');
imwrite(recImgA, imgName);

%% build a panorama
RimgB = imref2d(size(imgB));

[panoImg, Rpano] = stitchPano(recImgA, RrecImgA, imgB, RimgB);
%[panoImg, Rpano] = imfuse(recImgA, RrecImgA, imgB, RimgB, 'blend','Scaling','none');

% show image
%figure(2), imshow(panoImg,Rpano);
%stitch(imgA, imgB, H);
panoName = strcat('RANSAC', int2str(20), '_pano.jpg');
imwrite(panoImg, panoName);
end

