function [f, inlierIdx] = ransac1( x,y,ransacCoef,funcFindF,funcDist,funcDege )
%[f inlierIdx] = ransac1( x,y,ransacCoef,funcFindF,funcDist,funcDege)
%	Use RANdom SAmple Consensus to find a homography from points set X to points set Y.
%	X is 2*n matrix including n points, Y is 2*n;
%	The homography, and the indices of inliers, are returned.
%
%	RANSACCOEF is a struct with following fields:
%	minPtNum,iterMaxNum,iterNum,thDist,thInlrRatio
%	MINPTNUM is the minimum number of point correspondences with which can we find a homography (i.e 4)
%	ITERMAXNUM is the maximum number of iterations
%   ITERNUM is the number of iteration (for fixed number of iterations)
%   THDIST is the inlier distance threshold and ROUND(THINLRRATIO*n) is the inlier number threshold.
%
%	FUNCFINDF is a func handle for calculating homography through Normalized DLT algorithm
%	FUNCDIST is a func handle for calculate distance error given a homography
%   FUNCDEGE is a func handle for detecting degenerate situation


minPtNum = ransacCoef.minPtNum;
iterMaxNum = ransacCoef.iterMaxNum;
iterNum = ransacCoef.iterNum;
thInlrRatio = ransacCoef.thInlrRatio;
thDist = ransacCoef.thDist;
ptNum = size(x,2);
thInlr = round(thInlrRatio*ptNum);

%% adaptively iterate, keep max
inlrMaxNum = 0;
stdMinDiv = inf;
fMax = zeros(3);

N = inf; % initial value of iterations
sampleCount = 0;
p = 1;
% main loop
while N > sampleCount && p <= iterMaxNum
    % 1. fit using random points
	sampleIdx = randIndex(ptNum,minPtNum);
    while funcDege(x(:,sampleIdx),y(:,sampleIdx)) 
        sampleIdx = randIndex(ptNum,minPtNum);
    end
	f1 = funcFindF(x(:,sampleIdx),y(:,sampleIdx));
    
    % 2. count the inliers
	dist = funcDist(f1,x,y);
	inlier1 = find(dist < thDist);
    [~,errVec] = calError(f1,x(:,inlier1),y(:,inlier1), 'alg');
    tmpStd = sqrt(var(errVec,1));
    if length(inlier1) > inlrMaxNum 
        inlrMaxNum = length(inlier1);
        stdMinDiv = tmpStd;
        fMax = f1;
    elseif length(inlier1) == inlrMaxNum && tmpStd < stdMinDiv %tie
        stdMinDiv = tmpStd;
        fMax = f1;
    end
	
    % 3. update N
    otlrRate = 1 - length(inlier1)/ptNum;
    N = floor(log(1-0.99)/log(1-(1-otlrRate)^minPtNum));
    % 4. update parameters
    p = p+1;
    sampleCount = sampleCount+1;
    
end
N,sampleCount
%  choose the coef with the most inliers
f = fMax;
dist = funcDist(fMax,x,y);
inlierIdx = find(dist < thDist);

% %% adaptive iteration, keep all 
% % fixed number of iteration
% % inlrNum = zeros(1,iterMaxNum);
% % fLib = cell(1,iterMaxNum);
% 
% inlrNum = [];
% fLib = [];
% 
% N = inf; % initial value of iterations
% sampleCount = 0;
% p = 1;
% % main loop
% while N > sampleCount && p <= iterMaxNum
%     % 1. fit using random points
% 	sampleIdx = randIndex(ptNum,minPtNum);
%     while funcDege(x(:,sampleIdx),y(:,sampleIdx)) 
%         sampleIdx = randIndex(ptNum,minPtNum);
%     end
% 	f1 = funcFindF(x(:,sampleIdx),y(:,sampleIdx));
%     
%     % 2. count the inliers
% 	dist = funcDist(f1,x,y);
% 	inlier1 = find(dist < thDist);
% 	inlrNum(p) = length(inlier1);
% 	%fLib{p} = funcFindF(x(:,inlier1),y(:,inlier1));
%     fLib{p} = f1;
%     % 3. update N
%     otlrRate = 1 - length(inlier1)/ptNum;
%     N = floor(log(1-0.99)/log(1-(1-otlrRate)^minPtNum));
%     % 4. update parameters
%     p = p+1;
%     sampleCount = sampleCount+1;
%     
% end
% N,sampleCount
% 
% 
% %% fixed number of iterations
% % inlrNum = zeros(1,iterNum);
% % fLib = cell(1,iterNum);
% % 
% % for p = 1:iterNum
% % 	% 1. fit using random points
% % 	sampleIdx = randIndex(ptNum,minPtNum);
% % 	f1 = funcFindF(x(:,sampleIdx),y(:,sampleIdx));
% % 	
% % 	% 2. count the inliers, if more than thInlr, refit; else iterate
% % 	dist = funcDist(f1,x,y);
% % 	inlier1 = find(dist < thDist);
% % 	inlrNum(p) = length(inlier1);
% % 	fLib{p} = funcFindF(x(:,inlier1),y(:,inlier1));
% %     if length(inlier1) < thInlr, continue; end
% % end
% 
% %  choose the coef with the most inliers
% [~,idx] = max(inlrNum);
% f = fLib{idx};
% dist = funcDist(f,x,y);
% inlierIdx = find(dist < thDist);
	
end