function [H, corrPtIdx] = findHomography(pts1,pts2,t)
% [H corrPtIdx] = findHomography(pts1,pts2,t)
%	Find the homography between two planes using a set of corresponding
%	points. RANSAC method is used.
%   t-distance threshold
%	corrPtIdx is the indices of inliers.


coef.minPtNum = 4;
coef.iterNum = 500;
coef.iterMaxNum = 1e10;
coef.thDist = t;
coef.thInlrRatio = .1;
rng(1,'twister'); % set seed
%[H, corrPtIdx] = ransac1(pts1,pts2,coef,@DLT,@sytDist,@isdegenerate);
[H, corrPtIdx] = ransac1(pts1,pts2,coef,@NDLT,@algbDist,@isdegenerate);
%[H, corrPtIdx] = ransac1(pts1,pts2,coef,@NDLT,@sytDist,@isdegenerate);
%[H, corrPtIdx] = ransac1(pts1,pts2,coef,@MLE,@algbDist,@isdegenerate);
end

function d2 = algbDist(H,pts1,pts2)
%	Project PTS1 to PTS3 using H, then calcultate the distances between
%	PTS2 and PTS3

n = size(pts1,2);
pts3 = H*[pts1;ones(1,n)];
pts3 = pts3(1:2,:)./repmat(pts3(3,:),2,1);
d2 = sum((pts2-pts3).^2,1);

end

function d2 = sytDist(H,pts1,pts2)
% Function to evaluate the symmetric transfer error of a homography with
% respect to a set of matched points as needed by RANSAC.
x1 = [pts1;ones(1,size(pts1,2))];
x2 = [pts2;ones(1,size(pts2,2))];
Hx1 = H*x1;
invHx2 = H\x2;

% make homogeneous scale to 1
x1 = hnormalise(x1);
x2 = hnormalise(x2);     
Hx1= hnormalise(Hx1);
invHx2 = hnormalise(invHx2); 
    
d2 = sum((x1-invHx2).^2)  + sum((x2-Hx1).^2);

end