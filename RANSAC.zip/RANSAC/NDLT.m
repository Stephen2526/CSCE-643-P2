function [ H ] = NDLT( pntsA, pntsB )
% Normalized DLT algorithm

pntsA = [pntsA;ones(1,size(pntsA,2))];
pntsB = [pntsB;ones(1,size(pntsB,2))];
[norPtsA, TA] = normalise2dpts(pntsA);
[norPtsB, TB] = normalise2dpts(pntsB);
norH = DLT(norPtsA, norPtsB);
H = TB\norH*TA;


end

