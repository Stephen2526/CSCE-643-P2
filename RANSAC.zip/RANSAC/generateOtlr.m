function [ptsAllA,ptsAllB] = generateOtlr( otlrNum )
%GENERATEOTLR Summary of this function goes here
%   Funcition randomly generate otlrNum outliers

% load inliers
pntsInlrA = [1992, 2082, 2086, 2090, 2098, 2155, 2254, 2261, 2161, 2280, 2175, 2336, 2446, 2456, 2345, 2351, 2463, 2472, 2484, 2366; 
           654, 636, 815, 941, 1382, 620, 598, 787, 803, 1385, 1385, 582, 558, 756, 773, 910, 896, 1102, 1389, 1388; 
           1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1];
pntsInlrB = [14., 116., 100., 89., 56., 195., 298., 285., 181., 248., 139., 380., 487., 475., 369., 359., 467., 458., 445., 333.; 
           620., 615., 800., 933., 1395., 610., 605., 794., 797., 1395., 1396., 601., 597., 786., 792., 926., 923., 1120., 1397., 1398.; 
           1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1.];
imgsize = [1875,2500];
N =otlrNum; % number of outliers
rng(1,'twister'); % set seed
% for image A
ptsX = randi(imgsize(2),1,N);
ptsY = randi(imgsize(1),1,N);
ptsOut = [ptsX;ptsY;ones(1,N)];
ptsAllA(1,:) = [pntsInlrA(1,:),ptsOut(1,:)];
ptsAllA(2,:) = [pntsInlrA(2,:),ptsOut(2,:)];
%ptsAllA(3,:) = [pntsInlrA(3,:),ptsOut(3,:)];

% for image B
ptsX = randi(imgsize(2),1,N);
ptsY = randi(imgsize(1),1,N);
ptsOut = [ptsX;ptsY;ones(1,N)];
ptsAllB(1,:) = [pntsInlrB(1,:),ptsOut(1,:)];
ptsAllB(2,:) = [pntsInlrB(2,:),ptsOut(2,:)];
%ptsAllB(3,:) = [pntsInlrB(3,:),ptsOut(3,:)];

end

